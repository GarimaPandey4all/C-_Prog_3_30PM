﻿using System;

namespace HelloWorld_demo
{
    class Program
    {
        static void Main(string[] args)
        {   
            const int a=10;  //constant fixed value
            int b=20, c;

            //a = 70;

            c = a+b; //30

            Console.WriteLine("Addition of two numbers is: {0}", c);
        }
    }
}
