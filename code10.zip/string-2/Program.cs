﻿using System;

namespace string_2
{
    class Program
    {
        static void Main(string[] args)
        {   
            // \"
            Console.WriteLine("Hello \"C#\" World!");

             // \'
            Console.WriteLine("Hello \'C#\' World!");

            //backslash \\--> \
            Console.WriteLine("This \\ is called backslash.");

            //escape characters
            // \n-->new line 

            Console.WriteLine("My Name is\nBrain Mentors.");

            //\t--> Tab

            Console.WriteLine("Hello\tWorld");
            Console.WriteLine("Brain\tMentors");

            //\b-->backspace

            Console.WriteLine("Brain\bn Mentors");


        }
    }
}
