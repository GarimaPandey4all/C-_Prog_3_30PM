﻿using System;

namespace string_3
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            a = 10;
            b = 20;

            Console.WriteLine(a+b);

            string x, y;

            x = "30";
            y = "59";

            Console.WriteLine(x+y);
        }
    }
}
