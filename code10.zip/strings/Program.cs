﻿using System;

namespace strings
{
    class Program
    {
        static void Main(string[] args)
        {
            //string : store text : store more than one character: "Hello World"

            string wish = "Hello";
            Console.WriteLine(wish);

            string txt = "Brain Mentors";
            Console.WriteLine("The length of the txt string is:" + txt.Length);

            Console.WriteLine(txt.ToUpper());
            Console.WriteLine(txt.ToLower());

            string firstname = "Brain";
            string lastname = "Mentors";

            //Console.WriteLine(firstname + lastname); // +-->concatenation

            //string name = string.Concat(firstname, lastname);
            //Console.WriteLine(name);
            //Console.WriteLine(string.Concat(firstname, lastname));

            //String Interpolation: $

            string fullName = $"My full name is: {firstname} {lastname}";

            Console.WriteLine(fullName); 

            //Access string

            Console.WriteLine(firstname[4]); // []-->subscript operator, [index]

            //Access string: IndexOf()

            Console.WriteLine(lastname.IndexOf("n"));

            //Substring()

            string name = "Brain Mentors";

            int pos = name.IndexOf("M");

            string lastname_ = name.Substring(pos);

            Console.WriteLine(lastname_);

        }
    }
}
