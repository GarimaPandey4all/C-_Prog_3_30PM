﻿using System;

namespace boolean
{
    class Program
    {
        static void Main(string[] args)
        {
            bool state = true;
            bool state2 = false;

            Console.WriteLine(state);
            Console.WriteLine(state2);

            int a ,b ;

            a = 10;
            b = 30;

            Console.WriteLine(a>b);

            Console.WriteLine(a == b);
        }
    }
}
