﻿using System;

namespace if_else
{
    class Program
    {
        static void Main(string[] args)
        {
            //if-else : Conditional/Decision Making Statements

            int a = 20, b = 10;

            if(a > b) // true
            Console.WriteLine("A is greater than B");
            else
            Console.WriteLine("A is not greater than B");
        }
    }
}
