﻿using System;

namespace EvenOddTernary
{
    class Program
    {
        static void Main(string[] args)
        {
            int number;
            string result;

            Console.WriteLine("Enter any number:");
            number = Convert.ToInt32(Console.ReadLine());

            result = ((number % 2) == 0) ? "Number is Even." : "Number is Odd.";
            Console.WriteLine(result);
        }
    }
}
