﻿using System;

namespace Ternary
{
    class Program
    {
        static void Main(string[] args)
        {
            int a , b, largest;

            Console.WriteLine("Enter any number for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any number for b:");
            b = Convert.ToInt32(Console.ReadLine());

            largest = (a>b) ? a : b;

            Console.WriteLine("Largest number is:" +largest);
        }
    }
}
