﻿using System;

namespace ifelse
{
    class Program
    {
        static void Main(string[] args)
        {
            //find largest number between three numbers

            int a, b, c, largest;

            Console.WriteLine("Enter any number for a:");
            a = Convert.ToInt32(Console.ReadLine());

            
            Console.WriteLine("Enter any number for b:");
            b = Convert.ToInt32(Console.ReadLine());

            
            Console.WriteLine("Enter any number for c:");
            c = Convert.ToInt32(Console.ReadLine());

            //Ternary Operator
            largest = ((a>b)) ? ((a>c) ? a : c) : ((b>c) ? b : c);

            Console.WriteLine("Largest number is:" +largest);        
        }
    }
}
