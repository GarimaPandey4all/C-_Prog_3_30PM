﻿using System;

namespace ifelse
{
    class Program
    {
        static void Main(string[] args)
        {
            //find largest number between three numbers

            int a, b, c;

            Console.WriteLine("Enter any number for a:");
            a = Convert.ToInt32(Console.ReadLine());

            
            Console.WriteLine("Enter any number for b:");
            b = Convert.ToInt32(Console.ReadLine());

            
            Console.WriteLine("Enter any number for c:");
            c = Convert.ToInt32(Console.ReadLine());

            //If-elseif-else

            if((a>b) && (a>c))
            Console.WriteLine("Largest number is:"+a);

            else if(b>c)
            Console.WriteLine("Largest number is:"+b);

            else
            Console.WriteLine("Largest number is:"+c);
        }
    }
}
