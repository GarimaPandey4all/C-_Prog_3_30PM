﻿using System;

namespace nestedifelse
{
    class Program
    {
        static void Main(string[] args)
        {
            //Nested If-else

            int a = 100;

            if(a == 100)
            {
                if(a > 90)
                {
                    Console.WriteLine("This is Inner If.");
                }
                else
                {
                    Console.WriteLine("This is Inner Else.");
                }
            }
            else
            Console.WriteLine("This is Outer Else.");
        }
    }
}
