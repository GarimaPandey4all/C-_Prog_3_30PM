﻿using System;

namespace switchStatement
{
    class Program
    {
        static void Main(string[] args)
        {
            //Switch Statements: Menu Driven Program

            int a, b;

            Console.WriteLine("Press 1. Addition.");
            Console.WriteLine("Press 2. Subtraction.");
            Console.WriteLine("Press 3. Multiplication.");
            Console.WriteLine("Press 4. Division.");
            Console.WriteLine("Please enter your choice:");
            int choice = Convert.ToInt32(Console.ReadLine());

            switch(choice)
            {
                case 1: 
                Console.WriteLine("Addition");
                Console.WriteLine("Enter any value for a:");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter any value for b:");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(a+b);
                break;

                case 2:
                Console.WriteLine("Subtraction");
                Console.WriteLine("Enter any value for a:");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter any value for b:");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(a-b);
                break;

                case 3:
                Console.WriteLine("Multiplication");
                Console.WriteLine("Enter any value for a:");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter any value for b:");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(a*b);
                break;

                case 4:
                Console.WriteLine("Division");
                Console.WriteLine("Enter any value for a:");
                a = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine("Enter any value for b:");
                b = Convert.ToInt32(Console.ReadLine());
                Console.WriteLine(a/b);
                break;

                default:
                Console.WriteLine("Invalid Choice.");
                break;
        }
        }
    }
}
