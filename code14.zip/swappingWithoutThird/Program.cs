﻿using System;

namespace swappingWithoutThird
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            //Swapping without using third variable

            //First - Way: + and - Operators

            a = a + b; // a = 5, b = 6, a = 11
            b = a - b; // a = 11, b = 6, b = 5
            a = a - b; // a = 11, b = 5, a = 6

            Console.WriteLine("After swapping the value of a is:" +a);
            Console.WriteLine("After swapping the value of b is:" +b);


            //Second - Way: * and / Operators

            a = a * b; // a = 6, b = 5, a = 30
            b = a / b; // a = 30, b = 5, b = 6
            a = a / b; // a = 30, b = 6, a = 5

            Console.WriteLine("After swapping the value of a is:" +a);
            Console.WriteLine("After swapping the value of b is:" +b);

            //Third - Way: XOR ^ Operator

            a = a ^ b; // a = 0000 0101, b = 0000 0110, a = 0000 0011 = 3
            b = a ^ b; // a = 0000 0011, b = 0000 0110, b = 0000 0101 = 5
            a = a ^ b; // a = 0000 0011, b = 0000 0101, a = 0000 0110 = 6

            Console.WriteLine("After swapping the value of a is:" +a);
            Console.WriteLine("After swapping the value of b is:" +b);


        }
    }
}
