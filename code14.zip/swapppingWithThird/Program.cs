﻿using System;

namespace swapppingWithThird
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;
            int temp;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            //Swapping using third variable

            temp = a; // a = 5, temp = 5
            a = b; // b = 6, a = 6
            b = temp; // temp = 5, b = 5

            Console.WriteLine("After swapping the value of a is:" +a);
            Console.WriteLine("After swapping the value of b is:" +b);
        }
    }
}
