﻿using System;

namespace do_WhileLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 1;

            /*
                    Initialization
                    do
                    {
                        //Block of Code
                        increment/decrement
                    }while(Condition);
            
            */


            do
            {
                //Block of Code Do-While Loop

                Console.WriteLine(i);
                i++;

            }while(i <= 5);
        }
    }
}
