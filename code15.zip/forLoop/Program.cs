﻿using System;

namespace forLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
                for(initialization; condition; increment/decrement)
                {
                    block of code of for loop
                }
            */

            int i;

            for(i=1; i<=5; i++)
            {
                //Block of Code
                Console.WriteLine(i);
            }
        }
    }
}
