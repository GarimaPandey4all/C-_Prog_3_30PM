﻿using System;

namespace loops
{
    class Program
    {
        static void Main(string[] args)
        {
           int i = 1; //index

           /*   Initialization
                while(Condition)
                {
                    Block of Code
                    Increment/Decrement
                }
           */

            while(i<=10)
            {
                Console.WriteLine("Hello, My name is BrainMentors.");
                i++;
            }
        }
    }
}
