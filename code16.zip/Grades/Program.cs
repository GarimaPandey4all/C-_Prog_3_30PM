﻿using System;

namespace Grades
{
    class Program
    {
        static void Main(string[] args)
        {
            int eng, science, math, GK, hindi;

            Console.WriteLine("Enter marks of English:");
            eng = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter marks of Hindi:");
            hindi = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter marks of Science:");
            science = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter marks of General Knowledge:");
            GK = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter marks of Maths:");
            math = Convert.ToInt32(Console.ReadLine());

            int sum = eng + hindi + science + math + GK;

            Console.WriteLine("Total Marks is:" +sum);

            double percentage = sum / 5;

            Console.WriteLine("Percentage is:{0}%" , percentage);

            if(percentage >= 50 && percentage <= 60)
            Console.WriteLine("Grade D");
            
            else if(percentage >= 60 && percentage <= 70)
            Console.WriteLine("Grade C");
            
            else if(percentage >= 70 && percentage <= 80)
            Console.WriteLine("Grade B");
            
            else if(percentage >= 80 && percentage <= 100)
            Console.WriteLine("Grade A");

            else
            Console.WriteLine("You are Fail...");

        }
    }
}
