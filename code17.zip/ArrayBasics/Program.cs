﻿using System;

namespace ArrayBasics
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] a = {10, 20, 30, 40, 50}; //array declaration And Initialization

            //Access values from array: First way
            Console.WriteLine(a[0]);
            Console.WriteLine(a[1]);
            Console.WriteLine(a[2]);
            Console.WriteLine(a[3]);
            Console.WriteLine(a[4]);

            Console.WriteLine("");

            //Access values from array: Second way
            for(int i=0; i<5; i++)
            {
                Console.WriteLine(a[i]);
            }

        }
    }
}
