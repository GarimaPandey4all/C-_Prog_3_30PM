﻿using System;

namespace BreakWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

            while(i<10)
            {
                if(i == 4)
                {
                    break;
                }
                Console.WriteLine(i);
                i++;
            }
            Console.WriteLine(i);
        }
    }
}
