﻿using System;

namespace Continue
{
    class Program
    {
        static void Main(string[] args)
        {
            int i;

            for(i=0; i<10; i++)
            {
                if(i == 4)
                {
                    continue; //jump to next iteration
                }
                Console.WriteLine(i);
            }
        }
    }
}
