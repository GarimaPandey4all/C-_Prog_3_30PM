﻿using System;

namespace ContinueWhile
{
    class Program
    {
        static void Main(string[] args)
        {
            int i = 0;

            while(i<10)
            {
                if(i == 4)
                {
                    i++;
                    continue; //next iteration
                }
                Console.WriteLine(i);
                i++;
            }
        }
    }
}
