﻿using System;

namespace ArrayGrade
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            int[] marks = {70, 80, 90, 97, 89, 50, 70};

            for(int i=0; i<marks.Length; i++)
            {
                sum += marks[i]; // sum = sum + marks[i]; 
            }

            Console.WriteLine("Total Marks is:"+sum);

            double percentage = sum / marks.Length;

            Console.WriteLine("Percentage is: {0}%",percentage);

            if(percentage >= 50 && percentage <= 60)
            Console.WriteLine("Grade D");
            
            else if(percentage >= 60 && percentage <= 70)
            Console.WriteLine("Grade C");
            
            else if(percentage >= 70 && percentage <= 80)
            Console.WriteLine("Grade B");
            
            else if(percentage >= 80 && percentage <= 100)
            Console.WriteLine("Grade A");

            else
            Console.WriteLine("Fail...");

        }
    }
}
