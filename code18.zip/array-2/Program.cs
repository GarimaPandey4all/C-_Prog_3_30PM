﻿using System;

namespace array_2
{
    class Program
    {
        static void Main(string[] args)
        {
            string[] arr = {"Brain", "Mentors", "C#"};

            Console.WriteLine(arr[2]);

            arr[1] = "C#";
            arr[2] = "development";

            for(int i=0; i<3; i++)
            Console.WriteLine(arr[i]);
        }
    }
}
