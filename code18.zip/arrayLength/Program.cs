﻿using System;

namespace arrayLength
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {1, 2, 3, 4, 5};

            Console.WriteLine(arr.Length); //Length: provide the length/size of the array

            for(int i=0; i<arr.Length; i++)
            {
                Console.WriteLine(arr[i]);
            }
        }
    }
}
