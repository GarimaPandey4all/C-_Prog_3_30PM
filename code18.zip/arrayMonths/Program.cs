﻿using System;

namespace arrayMonths
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] days = {31, 29, 30, 31, 30, 31, 30, 31, 30, 30, 31, 30};

            for(int i=0; i<days.Length; i++)
            {
                Console.WriteLine("Month {0} has {1} days.", i+1, days[i]);
            }
        }
    }
}
