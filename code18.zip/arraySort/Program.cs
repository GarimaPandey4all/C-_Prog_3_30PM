﻿using System;

namespace arraySort
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = {50, 20, 10, 30, 40}; //unsorted array

            //Sort the array

            Array.Sort(arr); //Sort the array

            foreach(int i in arr)
            {
                Console.WriteLine(i);
            }



        }
    }
}
