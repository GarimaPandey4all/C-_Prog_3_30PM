﻿using System;

namespace forEachLoop
{
    class Program
    {
        static void Main(string[] args)
        {
            //Array: foreach loop

            int[] arr = {10, 20, 30, 40, 50};
            
            //foreach(type variablename in arrayname)
            foreach(int i in arr)
            {
                Console.WriteLine(i);
            }
        }
    }
}
