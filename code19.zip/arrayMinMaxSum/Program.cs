﻿using System;
using System.Linq; //Linq: Language Integrated Query

namespace arrayMinMaxSum
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] numbers = {10, 30, 20, 50, 40};

            //Array's Functions
            Console.WriteLine("Minimum value in the array is:"+numbers.Min());
            Console.WriteLine("Maximum value in the array is:"+numbers.Max());
            Console.WriteLine("Sum of the array is:"+numbers.Sum());
        }
    }
}
