﻿using System;

namespace Example
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!"); //WriteLine: print always at the new line
            Console.Write("Brain Mentors..."); // ; --> semicolon: end of the line //Write()--> print always at the same line
        }
    }
}
