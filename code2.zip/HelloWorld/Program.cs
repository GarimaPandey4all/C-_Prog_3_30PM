﻿//using System; //-->comment //using system means that we use classes from the system namespace

namespace HelloWorld
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!"); //Writeline--> output / print text on the output screen. 
        }
    }
}