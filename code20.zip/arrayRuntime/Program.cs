﻿using System;

namespace arrayRuntime
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] arr = new int[5]; // 5 size of the array
            int i;

            Console.WriteLine("Enter values in an array:");
            for(i=0; i<arr.Length; i++)
            arr[i] = Convert.ToInt32(Console.ReadLine()); // Insert values in an array

            Console.WriteLine("Values in an array:");
            for(i=0; i<arr.Length; i++)
            Console.WriteLine(arr[i]);

        }
    }
}
