﻿using System;

namespace multiArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int i, j;

            string[,] books = new string[3, 3]; // 2D- Array : rows = 3, cols = 3

            //Nested Loops
            Console.WriteLine("Enter book name:");
            for(i=0; i<3; i++) // this loop is for row // Outer Loop
            {
                for(j=0; j<3; j++) // this loop is for column // Inner Loop
                {
                    books[i, j] = Console.ReadLine();
                }
            }

            Console.WriteLine("book names are:");
            for(i=0; i<3; i++) // this loop is for row // Outer Loop
            {
                for(j=0; j<3; j++) // this loop is for column // Inner Loop
                {
                    Console.Write("{0}\t", books[i, j]);
                }
                Console.Write("\n"); //Next Line
            }
        }
    }
}
