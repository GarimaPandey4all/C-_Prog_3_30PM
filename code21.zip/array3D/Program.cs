﻿using System;

namespace array3D
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,,] arr= new int[2, 2, 2];
            int i, j, k;

            Console.WriteLine("Enter values in an Array:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<2; j++)
                {
                    for(k=0; k<2; k++)
                    {
                        arr[i, j, k] = Convert.ToInt32(Console.ReadLine());
                    }
                }
            }

            Console.WriteLine("Values in an Array are:");
            for(i=0; i<2; i++)
            {
                for(j=0; j<2; j++)
                {
                    for(k=0; k<2; k++)
                    {
                        Console.Write("{0}\t", arr[i, j, k]);
                    }
                }
            }
        }
    }
}
