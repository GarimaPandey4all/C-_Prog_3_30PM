﻿using System;

namespace function
{
    class Program
    {
        //1. Without function parameter and without return type
        static void HelloWorld() // Function Definition
        {
            //function's body // block of code
            Console.WriteLine("Hello World");
        }

        static void Main(string[] args)
        {
           HelloWorld(); //Function calling from the main() 
           HelloWorld();
           HelloWorld();
           HelloWorld();
           HelloWorld();
        }
    }
}
