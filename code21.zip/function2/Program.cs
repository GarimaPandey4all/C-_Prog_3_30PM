﻿using System;

namespace function2
{
    class Program
    {   
        //2. With function parameter and without return type
        static void FuncSum(int a, int b) // a, b: Function Parameters/Formal Parameters
        {
            Console.WriteLine("Addition is:" +(a+b));
        }

        static void Main(string[] args)
        {
            FuncSum(10, 20); //10, 20: Function Arguments/Actual Parametres
            FuncSum(50, 80);
            FuncSum(40, 20);            
        }
    }
}
