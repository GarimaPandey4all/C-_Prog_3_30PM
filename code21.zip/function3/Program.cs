﻿using System;

namespace function3
{
    class Program
    {
        //3. With function parameters and with return type
        static int FuncSum(int a, int b) // a, b: Function Parameters/Formal Parameters
        {
            return (a+b);
        }

        static void Main(string[] args)
        {
            int sum = FuncSum(10, 20); //10, 20: Function Arguments/Actual Parametres

            Console.WriteLine("Addition is:"+sum);
        }
    }
}
