﻿using System;

namespace function4
{
    class Program
    {
        //4. Without function parameters and with return type
        static int FuncSum() 
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());
            
            Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            //Console.WriteLine("Addition is:"+(a+b));   

            return (a+b); 
            //return 0;  // 0 - null   
        }

        static void Main(string[] args)
        {
            Console.WriteLine("Addition is:"+FuncSum());     
            //FuncSum();
        }
    }
}
