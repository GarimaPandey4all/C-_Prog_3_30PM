﻿using System;

namespace matrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix1 = new int[3, 3];
            int[,] matrix2 = new int[3, 3];
            int[,] result = new int[3, 3];
            int i, j;

            Console.WriteLine("Enter values in Matrix-1:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix1[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Enter values in Matrix-2:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix2[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix-1 are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix1[i,j]);
                }
                Console.WriteLine("\n");
            }

            Console.WriteLine("Values in Matrix-2 are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix2[i,j]);
                }
                Console.WriteLine("\n");
            }

            //Addition logic of Matrixes
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    result[i, j] = matrix1[i, j] + matrix2[i, j];
                }
            }

            Console.WriteLine("Addition of Two Matrices is:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", result[i,j]);
                }
                Console.WriteLine("\n");
            }
        }
    }
}
