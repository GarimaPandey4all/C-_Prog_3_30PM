﻿using System;

namespace principalDiagonal
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3,3];
            int i, j;

            Console.WriteLine("Enter values in Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine("\n");
            }

            //Logic for Principal Diagonal
            Console.WriteLine("Principal Diagonal is:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    if(i == j)
                    Console.Write("{0}\t", matrix[i, j]);
                }
            }
        }
    }
}
