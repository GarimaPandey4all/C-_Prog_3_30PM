﻿using System;

namespace sparseMatrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3,3];
            int i, j;
            int total = 0; // flag variable

            Console.WriteLine("Enter values in Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine("\n");
            }

            //Logic for Sparse Matrix
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    if(matrix[i, j] == 0)
                     total++; // count number of zeroes
                }
            }

            if(total > ((matrix.Length)/2))
                Console.WriteLine("Sparse Matrix");
            else
                Console.WriteLine("Not a Sparse Matrix");

        }
    }
}
