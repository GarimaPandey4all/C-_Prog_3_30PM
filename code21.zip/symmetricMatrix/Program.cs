﻿using System;

namespace symmetricMatrix
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] matrix = new int[3,3];
            int[,] temp = new int[3, 3];
            int count = 0;
            int i, j;

            Console.WriteLine("Enter values in Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    matrix[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }

            Console.WriteLine("Values in Matrix are:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", matrix[i, j]);
                }
                Console.WriteLine("\n");
            }

            //Logic for Transpose Matrix
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    temp[j, i] = matrix[i, j];
                }
            }

            Console.WriteLine("Transpose of a Matrix:");
            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    Console.Write("{0}\t", temp[i, j]);
                }
                Console.WriteLine("\n");
            }

            for(i=0; i<3; i++)
            {
                for(j=0; j<3; j++)
                {
                    if(matrix[i, j] != temp[i, j])
                    {
                        count++; // count = 1, we can jump out this loop
                        break;
                    }
                }
            }

            if(count == 0)
                Console.WriteLine("Symmetric Matrix");
            else
                Console.WriteLine("Not a Symmetric Matrix");
        }
    }
}
