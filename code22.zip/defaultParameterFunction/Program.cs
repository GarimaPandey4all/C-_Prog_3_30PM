﻿using System;

namespace defaultParameterFunction
{
    class Program
    {   
        //Default Parameter Value
        static void myFunc(string name = "Brain Mentors")
        {
            Console.WriteLine(name);
        }

        static void Main(string[] args)
        {
            myFunc("Garima");
            myFunc();
        }
    }
}
