﻿using System;

namespace namedArgumentsFunction
{
    class Program
    {
        //Named Arguments: key:value
        // static void myFunc(string firstName, string lastName)
        // {
        //     Console.WriteLine("Full Name is:{0} {1}", firstName, lastName);
        // }

        static void myFunc(string firstName = "Brain", string lastName = "Mentors")
        {
            Console.WriteLine(lastName);
        }

        static void Main(string[] args)
        {
            //myFunc("Brain", "Mentors");
            //key : firstName, lastName :: "Brain", "Mentors" : key's value
            // myFunc(firstName: "Brain", lastName: "Mentors");  

            myFunc("lastName");
            myFunc("Garima", "Pandey");
        }
    }
}
