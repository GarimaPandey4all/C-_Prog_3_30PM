﻿using System;

namespace ClassesandObjects_2
{
    class Car
    {
        string color;
        string model;
        int year;

        static void Main(string[] args)
        {
            Car MarutiSuzuki = new Car();

            MarutiSuzuki.color = "Gray";
            MarutiSuzuki.model = "MZ";
            MarutiSuzuki.year = 2019;

            Console.WriteLine(MarutiSuzuki.color);
            Console.WriteLine(MarutiSuzuki.model);
            Console.WriteLine(MarutiSuzuki.year);

            Car Honda = new Car();

            Honda.color = "Black";
            Honda.model = "HN";
            Honda.year = 2017;

            Console.WriteLine(Honda.color);
            Console.WriteLine(Honda.model);
            Console.WriteLine(Honda.year);

        }
    }
}
