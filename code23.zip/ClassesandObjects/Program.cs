﻿using System;

namespace ClassesandObjects
{   //DRY: Don't Repeat Yourself
    //Class HelloWorld
    class HelloWorld
    {
        /*Class Members*/

        //Data Member / Attribute / field
        string text = "Hello World";

        //Customize/User Defined Function  //Member Method/Function
        void showData()
        {
            Console.WriteLine(text);
        }

        //Pre-Defined Function //Member Method/Function
        static void Main(string[] args)
        {   
            //Object create: obj
            HelloWorld obj = new HelloWorld(); //first object
            HelloWorld obj2 = new HelloWorld(); // second object
            Console.WriteLine(obj.text); // call class's attribute

            //Call class's method
            obj.showData();
            obj2.showData();
        }
    }
}
