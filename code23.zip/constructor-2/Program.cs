﻿using System;

namespace constructor_2
{
    class Human
    {
        string name; // class field
        int age;

        Human(string personName, int personAge) // Parameterized Constructor
        {
            name = personName; 
            age = personAge; 
        }

        static void Main(string[] args)
        {
            Human Rishi = new Human("Rishi", 20);
            Console.WriteLine(Rishi.name + " " + Rishi.age);
        }
    }
}
