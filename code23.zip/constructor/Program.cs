﻿using System;

namespace constructor
{
    class Human
    {
        string name; 

        //Constructor : Special Method because class name and constructor name both are same. Constructor is called when the object is created.
        Human() // it can't have a return type like void or int etc.
        {
            name = "Rishi";
        }

        static void Main(string[] args)
        {
            Human Rishi = new Human();
            Console.WriteLine(Rishi.name);
        }
    }
}
