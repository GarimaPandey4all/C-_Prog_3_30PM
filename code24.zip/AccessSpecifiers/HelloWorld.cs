using System;

namespace AccessSpecifiers
{
    class HelloWorld
    {
        //private string text = "Hello Brain";

        public string text = "Hello Brain";
    }
}
