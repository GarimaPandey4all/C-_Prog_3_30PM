﻿using System;

namespace AccessSpecifiers
{
    class Program
    {
        //Access Modifiers : Private (Default), Public, Protected, Internal

        //private string text = "Hello Brain"; // private field

        static void Main(string[] args)
        {
            HelloWorld obj = new HelloWorld();
            Console.WriteLine(obj.text);            
        }
    }
}
