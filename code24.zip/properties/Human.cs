using System;

namespace properties
{
    class Human
    {
        //private string name; // field/Data Member

        public string Name // property
        {
            // get {
            //     return name;
            //     }

            // set {
            //     name = value;
            // }

            //Short-Hand of Property
            get;
            set;
        }  
    }
}
