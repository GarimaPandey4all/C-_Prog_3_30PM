﻿using System;

namespace properties
{
    class Program
    {
        static void Main(string[] args)
        {
            Human obj = new Human();
            obj.Name = "Brain Mentors";
            Console.WriteLine(obj.Name);
        }
    }
}
