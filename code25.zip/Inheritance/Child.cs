using System;

namespace Inheritance
{
    //Derived Class // Inheritance
    class Child : Parent
    {
        public int id_Child = 123;

        public void showData()
        {
            Console.WriteLine("This is Child Class");
        }
    }
}
