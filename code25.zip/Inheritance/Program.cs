﻿using System;

namespace Inheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Child obj = new Child();

            Console.WriteLine(obj.id_Child);
            obj.showData();

            Console.WriteLine(obj.id_Parent);
            obj.display();
        }
    }
}
