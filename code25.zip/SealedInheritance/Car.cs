using System;

namespace SealedInheritance
{
    //Base Class
    class Car : Vehicle
    {
        public string model = "M5";
    }
}
