﻿using System;

namespace SealedInheritance
{
    class Program
    {
        static void Main(string[] args)
        {
            Car obj = new Car();

            Console.WriteLine(obj.model);
            Console.WriteLine(obj.brand);
        }
    }
}
