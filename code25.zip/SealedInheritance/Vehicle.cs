using System;

namespace SealedInheritance
{
    //Base Class
    sealed class Vehicle
    {
        public string brand = "Maruti Suzuki";

    }
}
