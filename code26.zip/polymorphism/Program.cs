﻿using System;

namespace polymorphism
{   
    //Base Class
    class Animal
    {
        public virtual void animalSound()
        {
            Console.WriteLine("Animal Sound");
        }
    }

    //Derived Class
    class Dog : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Dog says... bhau bhau");
        }
    }    

    //Derived Class
    class Cat : Animal
    {
        public override void animalSound()
        {
            Console.WriteLine("Cat says... meou meou");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Animal obj = new Animal(); //Parent class Object
            Animal obj1 = new Dog(); // Child/Dog class Object
            Animal obj2 = new Cat(); //Child/Cat class Object

            obj.animalSound();
            obj1.animalSound();
            obj2.animalSound();
        }
    }
}
