﻿using System;

namespace Interfaces
{
    // An interface is an completely abstract class which can only contain abstract functions and properties.
    // By default, in interface the members of an interface are public and abstract.

    //Interface : abstract class
    interface Animal
    {
        void animalSound(); // only declare
    }

    class Dog : Animal
    {
        public void animalSound()   
        {
            Console.WriteLine("Dog says... bhau bhau");
        }
    }

    class Cat : Animal
    {
        public void animalSound()   
        {
            Console.WriteLine("Cat says... meou meou");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Dog obj = new Dog();
            obj.animalSound();

            Cat obj1 = new Cat();
            obj1.animalSound();
        }
    }
}
