﻿using System;

namespace MultipleInterfaces
{
    //Not supported in C#: Multiple Inheritance
    // class child : A, B
    // {

    // }

    interface FirstInterface
    {
        void display();
    }

    interface SecondInterface
    {
        void showData();
    }

    //Implement multiple interfaces
    class Child : FirstInterface, SecondInterface
    {
        public void display()   
        {
            Console.WriteLine("It is First Interface");
        }

        public void showData()   
        {
            Console.WriteLine("It is Second Interface");
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Child obj = new Child();
            obj.display();
            obj.showData();            
        }
    }
}
