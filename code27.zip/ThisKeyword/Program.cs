﻿using System;

namespace ThisKeyword
{   
    class Add
    {
        public int a, b;

        public Add(int a, int b)
        {
            // class fields = instance variable // this keyword is used to differentiate the class fields and method parameters as the they have same name
            // this keyword refer to the current class
            this.a = a;
            this.b = b;
        }

        public void display() 
        {
            Console.WriteLine("Addition is:"+(a+b));
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Add obj = new Add(10, 20);
            Add obj1 = new Add(30, 50);

            obj.display();
            obj1.display();
        }
    }
}
