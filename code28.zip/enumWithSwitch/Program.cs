﻿using System;

namespace enumWithSwitch
{
    class Program
    {
        enum colors
        {
            red,
            yellow,
            blue
        }

        static void Main(string[] args)
        {
            colors myColor = colors.red;

            switch(myColor)
            {
                case colors.red:
                Console.WriteLine("Red Color");
                break;

                case colors.yellow:
                Console.WriteLine("Yellow Color");
                break;

                case colors.blue:
                Console.WriteLine("Blue Color");             
                break;
            }
        }
    }
}
