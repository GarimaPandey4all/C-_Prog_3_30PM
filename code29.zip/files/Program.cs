﻿using System;
using System.IO;

namespace files
{
    class Program
    {
        static void Main(string[] args)
        {
            //The file class from the System.IO namespace, allows us to work with files.
            string writeText = "Hello, How are you?";
            File.WriteAllText("test.txt", writeText); // Create a file and write the content into this file.|

            //Console.WriteLine(writeText);
        }
    }
}
