﻿using System;
using System.IO;

namespace filesAppendData
{
    class Program
    {
        static void Main(string[] args)
        {
            string myFile = @"test.txt";

            //Stream : Flow of data
            using(StreamWriter sw = File.CreateText(myFile))
            {
                sw.WriteLine("Hello World");
            }

            //Append the content in the existing file
            using(StreamWriter sw = File.AppendText(myFile))
            {
                sw.WriteLine("How are you?");
                sw.WriteLine("My name is Rishi.");
            }

             using(StreamReader sr = File.OpenText(myFile))
            {
                string readText = "";
                while((readText = sr.ReadLine()) != null)
                {
                    Console.WriteLine(readText);
                }
            }
        }
    }
}
