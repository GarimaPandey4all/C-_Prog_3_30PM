﻿using System;
using System.IO;

namespace filesReadData
{
    class Program
    {
        static void Main(string[] args)
        {
            string readText = File.ReadAllText("test.txt"); // Read Content from the File.
            Console.WriteLine(readText);
        }
    }
}
