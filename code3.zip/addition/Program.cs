﻿using System;

namespace addition
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;

            int c = a + b;

            Console.WriteLine("Addition of two numbers is:{0}", c);
        }
    }
}
