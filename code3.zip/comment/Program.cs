﻿//using System;

/*
    This is an example of Hello World.
    Developer: Brain Mentors
    Last Modified Date: 2-7-2020
*/

/*Developed by Brain Mentors...*/
namespace comment
{
    class Program
    {
        static void Main(string[] args)
        {
            System.Console.WriteLine("Hello World!"); 
        }
    }
}
