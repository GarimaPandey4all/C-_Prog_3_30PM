﻿using System;

namespace formatting
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 20;
            int c = 30;

            Console.WriteLine(a + b + c); 

            string name = "Brain Mentors";

            Console.WriteLine("Hello " + name); // '+'--> concatenation or join
        }
    }
}
