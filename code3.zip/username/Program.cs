﻿using System;

namespace username
{
    class Program
    {
        static void Main(string[] args)
        {
            string firstname = "Brain ";
            string lastname = "Mentors";

            Console.WriteLine(firstname + lastname); //concatenation/joining
        }
    }
}
