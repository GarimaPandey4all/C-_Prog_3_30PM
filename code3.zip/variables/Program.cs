﻿using System;

namespace variables
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10; //variable declaration and initialization/assignment

            a = 40; //reassign

           const int b = 20; //const--> fixed the value of the variable

            //b = 50; //error 

            Console.WriteLine(a);

            Console.WriteLine(b);

            string name = "Brain Mentors";
            string name1 = " C#";

            Console.Write(name);
            Console.WriteLine(name1);

            double d; //only declare

            d = 23.56;

            Console.WriteLine(d);

            char c;

            c = 'A';

            Console.WriteLine(c);

            bool state = false;

            Console.WriteLine(state);
        }
    }
}