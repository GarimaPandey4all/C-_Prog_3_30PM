﻿using System;

namespace Exceptions_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter value for a:");
            a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            try
            {
                int c = a / b; // 10/0 = infinity
                Console.WriteLine("Division of two numbers is:"+c);
            }

            catch (Exception e)
            {
                Console.WriteLine(e.Message);
            }

            //finally: The finally statement lets you execute code, after try and catch blocks.

            finally
            {
                Console.WriteLine("Try-Catch are finished.");
            }
        }
    }
}
