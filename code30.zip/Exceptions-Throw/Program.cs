﻿using System;

namespace Exceptions_Throw
{
    //Throw : The throw statement allows you to create a custom error.
            /*
                There are many exception classes available in C#.
                1. ArithmeticException
                2. FileNotFoundException
                3. IndexOutOfRangeException
                4. TimeOutException
            */

    class Program
    {
        static void findAge(int age)
        {
            if(age < 20)
            {
                throw new ArithmeticException("Not matched with age limit.");
            }

            else 
            {
                Console.WriteLine("You are matched with the age limit.");
            }
        }

        static void Main(string[] args)
        {
            findAge(20);           
        }
    }
}
