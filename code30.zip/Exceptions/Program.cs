﻿using System;

namespace Exceptions
{
    //Exceptions:
    /*
        try and catch:

        try: The try statement allows you to define a block of code to be tested for errors while it is being executed.

        catch: The catch statement allows you to define a block of code to be executed, if an error occurs in the try block.

        try 
        {

        }
        catch (Exception e)
        {

        }
    */

    class Program
    {
        static void Main(string[] args)
        {
            try{
                int[] digits = {10, 20, 30, 40, 50};
                Console.WriteLine(digits[6]);
            }

            catch (Exception e)
            {
                //Console.WriteLine(e.Message);
                Console.WriteLine("Invalid Range. Index out of range Error.");
            }
        }
    }
}
