﻿using System;

namespace factorial
{
    class Program
    {
        static void Main(string[] args)
        {
            int fact = 1;
            
            Console.WriteLine("Enter any number that you want to find the factorial:");
            int n = Convert.ToInt32(Console.ReadLine());

            for(int i=1; i<=n; i++)
            {
                fact *= i; // fact = fact * i; 
            }

            Console.WriteLine("Factorial of a given number is:" +fact);
        }
    }
}
