﻿using System;

namespace fibonacciSeries
{
    class Program
    {
        static void Main(string[] args)
        {
            int n1 = 0, n2 = 1;
            int n3;

            Console.WriteLine("Enter any number to find the Fibonacci Series:");
            int n = Convert.ToInt32(Console.ReadLine());

            Console.Write("Fibonacci Series of {0} this given number is:{1}\t{2}\t", n, n1, n2);
            for(int i=2; i<n; i++)
            {
                n3 = n1 + n2;
                Console.Write("{0}\t", n3);
                n1 = n2;
                n2 = n3;
            }
        }
    }
}
