﻿using System;

namespace jaggedArray_11_30AM
{
    class Program
    {
        static void Main(string[] args)
        {
            //Jagged Array : Array of Arrays
            int[][] arr = new int[2][] {new int[] {1, 2, 3, 4, 5} , new int[] {10, 20, 30}};

            //Size Declare
            // arr[0] new int[5];
            // arr[1] new int[3];

            // arr[0] = new int[] {1, 2, 3, 4, 5};
            // arr[1] = new int[] {10, 20, 30};

            for(int i=0; i<arr.Length; i++) //arr.Length = 2
            {
                for(int j=0; j<arr[i].Length; j++) // arr[i].Length = arr[0].Length = 5; arr[1].Length = 3
                {
                    Console.Write("{0}\t", arr[i][j]);
                }
                Console.WriteLine();
            }
        }
    }
}
