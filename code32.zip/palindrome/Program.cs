﻿using System;

namespace palindrome
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            Console.WriteLine("Enter any number that you want to check the given number is palindrome or not:");
            int n = Convert.ToInt32(Console.ReadLine());

            int temp = n;

            while(n > 0)
            {
                int remainder = n % 10;
                sum = sum * 10 + remainder;
                n = n / 10;
            }

            n = temp;

            if(sum == n)
            Console.WriteLine("Palindrome Number");
            else
            Console.WriteLine("Not a Palindrome Number");
        }
    }
}
