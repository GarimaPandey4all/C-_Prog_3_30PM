﻿using System;

namespace pattern_2
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i='A'; i<='E'; i++) // A - 65 to 90 - Z // a - 97 to z - 122
            {
                for(char j='A'; j<='E'; j++)
                {
                    Console.Write(i);
                    //Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
