﻿using System;

namespace pattern_3
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i='a'; i<='e'; i++) // a - 97 to z - 122
            {
                for(char j='a'; j<='e'; j++)
                {
                    //Console.Write(i);
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
