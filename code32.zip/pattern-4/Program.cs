﻿using System;

namespace pattern_4
{
    class Program
    {
        static void Main(string[] args)
        {
            for(int i=5; i>=1; i--)
            {
                for(int j=5; j>=1; j--)
                {
                    Console.Write(i);
                    //Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
