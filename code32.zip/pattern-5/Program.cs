﻿using System;

namespace pattern_5
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i='E'; i>='A'; i--) // A - 65 to 90 - Z // a - 97 to z - 122
            {
                for(char j='E'; j>='A'; j--)
                {
                    Console.Write(i);
                    //Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
