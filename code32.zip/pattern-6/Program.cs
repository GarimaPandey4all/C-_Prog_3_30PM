﻿using System;

namespace pattern_6
{
    class Program
    {
        static void Main(string[] args)
        {
            for(char i='e'; i>='a'; i--) // a - 97 to z - 122
            {
                for(char j='e'; j>='a'; j--)
                {
                    //Console.Write(i);
                    Console.Write(j);
                }
                Console.WriteLine();
            }
        }
    }
}
