﻿using System;

namespace reverseNumber
{
    class Program
    {
        static void Main(string[] args)
        {
            int reverse = 0;

            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            while(n > 0)
            {
                int remainder = n % 10;
                reverse = reverse * 10 + remainder;
                n = n / 10;
            }

            Console.WriteLine("Reverse number is:"+reverse);
        }
    }
}
