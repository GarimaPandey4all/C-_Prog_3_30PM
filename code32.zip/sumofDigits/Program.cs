﻿using System;

namespace sumofDigits
{
    class Program
    {
        static void Main(string[] args)
        {
            int sum = 0;

            Console.WriteLine("Enter any number:");
            int n = Convert.ToInt32(Console.ReadLine());

            while(n > 0)
            {
                int remainder = n % 10; // n = 432 = 2 = 3 = 4
                sum = sum + remainder; // sum = 2+ 3 = 5 + 4 = 9
                n = n / 10; // n = 43, 4, 0
            }

            Console.WriteLine("Sum of Digits:"+sum);
        }
    }
}
