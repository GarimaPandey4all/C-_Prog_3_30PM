﻿using System;

delegate int Numberchanger(int n);
namespace delegates
{
    class Program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num = num + a;
            return num;
        }

        public static int Mul(int a)
        {
            num = num * a;
            return num;
        }

        public static int display()
        {
            return num;
        }

        static void Main(string[] args)
        {
            //Delegates are similar to pointers to functions in C or C++. 
            //A delegate is a reference/address type variable that holds the reference to a method. 
            //The reference can be changed at runtime.

            //Delegates drived from the System.Delegate class

            //How to declare delegate in a program
            //public delegate int MyDelegate (int i);
            //delegate <return-type> <delegate-name> <parameter-list>

            //Instantating Delegates
            //MyDelegate d1 = new MyDelegate();

            Numberchanger obj1 = new Numberchanger(Add);
            Numberchanger obj2 = new Numberchanger(Mul);

            obj1(20);
            Console.WriteLine("Addition is:{0}", display());

            obj2(5);
            Console.WriteLine("Multiplication is:{0}", display());
        }
    }
}
