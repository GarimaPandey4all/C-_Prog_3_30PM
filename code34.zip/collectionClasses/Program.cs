﻿using System;
using System.Collections;

namespace collectionClasses
{
    class Program
    {
        static void Main(string[] args)
        {
            //Collection Classes are specialized classes for data storage and retrieval. These classes support for stacks, arrays, linked lists and hash tables. Most Collection classes implement the same interfaces.
            // Classes of the System.Collection Namepsace.

            //1. ArrayList : It is an alternative to an array. ArrayList resizes itself automatically. It allows dynamic memory allocation, adding, searching and sorting items in the list.

            ArrayList al = new ArrayList();

            Console.WriteLine("Insertion in Array:");
            al.Add(10);
            al.Add(20);
            al.Add(30);
            al.Add(40);
            al.Add(5);

            Console.WriteLine("Count : {0}", al.Count);
            Console.WriteLine("Capacity : {0}", al.Capacity);

            Console.WriteLine("Values in an Array List are:");
            foreach(int i in al)
            Console.Write(i + "  ");
            Console.WriteLine();

            Console.WriteLine("Sorted Array List is:");
            al.Sort();
            foreach(int i in al)
            Console.Write(i + "  ");
            Console.WriteLine();

            //Remove particular element from the ArrayList
            al.Remove(5);
            foreach(int i in al)
            Console.Write(i + "  ");
            Console.WriteLine();

            //Remove all the elements from the ArrayList
            al.Clear();
            Console.WriteLine("Count : {0}", al.Count);
        }
    }
}
