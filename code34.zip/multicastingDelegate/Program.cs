﻿using System;

delegate int Numberchanger(int n);
namespace multicastingDelegate
{
    class program
    {
        static int num = 10;

        public static int Add(int a)
        {
            num = num + a;
            return num;
        }

        public static int Mul(int a)
        {
            num = num * a;
            return num;
        }

        public static int display()
        {
            return num;
        }
    
        static void Main(string[] args)
        {
            Numberchanger obj;
            Numberchanger obj1 = new Numberchanger(Add);
            Numberchanger obj2 = new Numberchanger(Mul);

//Delegate objects can be composed using the '+' operator. A composed delegate calls the two delegates it was composed from. Only delegates of the same ttpe can be composed. 
            obj = obj1;
            obj += obj2; // obj = obj + obj2;

            //Calling of Multicast
            obj(10);
            Console.WriteLine("Value of number is:{0}", display());
    }
}
}