﻿using System;
using System.Collections;

namespace bitarrayCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            //Creating bit array of size 8
            BitArray bit1 = new BitArray(8);
            BitArray bit2 = new BitArray(8);

            byte[] a = { 5 };
            byte[] b = { 4 };

            bit1 = new BitArray(a);
            bit2 = new BitArray(b);

            Console.WriteLine("Bit1 is:");
            for(int i=0; i<bit1.Count; i++)
                Console.Write(bit1[i] + "  ");
            Console.WriteLine();

            Console.WriteLine("Bit2 is:");
            for(int i=0; i<bit2.Count; i++)
                Console.Write(bit2[i] + "  ");
            Console.WriteLine();

            BitArray bit3 = new BitArray(8);
            bit3 = bit1.And(bit2);

            Console.WriteLine("Bit3 is:");
            for(int i=0; i<bit3.Count; i++)
                Console.Write(bit3[i] + "  ");
            Console.WriteLine();

            BitArray bit4 = new BitArray(8);
            bit4 = bit1.Or(bit2);

            Console.WriteLine("Bit4 is:");
            for(int i=0; i<bit4.Count; i++)
                Console.Write(bit4[i] + "  ");
            Console.WriteLine();
        }
    }
}
