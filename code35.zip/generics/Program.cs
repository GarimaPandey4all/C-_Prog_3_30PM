﻿using System;
using System.Collections.Generic;

namespace generics
{   
    //Generic Class
    public class MyGenericArray<T>
    {
        private T[] array;

        public MyGenericArray(int size){
            array = new T[size+1];
        }

        public T getItem(int index)
        {
            return array[index];
        }

        public void setItem(int index, T value)
        {
            array[index] = value;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //Generics: Allow you to write a class or method/function that can work with any data type.

            //Declare int Array
            MyGenericArray<int> intArray = new MyGenericArray<int>(5);

            //Setting values
            for(int i=0; i<5; i++)
            intArray.setItem(i, i*5);

            //Accessing values from an array
            for(int i=0; i<5; i++)
            Console.Write(intArray.getItem(i) + "  ");

            Console.WriteLine();

            //Declare int Array
            MyGenericArray<char> charArray = new MyGenericArray<char>(5);

            //Setting values
            for(int i=0; i<5; i++)
            charArray.setItem(i, (char)(i+65)); // 65 - A, 97 - a

            //Accessing values from an array
            for(int i=0; i<5; i++)
            Console.Write(charArray.getItem(i) + "  ");
            Console.WriteLine();
        }
    }
}
