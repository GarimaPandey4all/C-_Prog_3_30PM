﻿using System;
using System.Collections.Generic;

namespace genericsMethod
{
    class Program
    {
        //Function/Method Generics
        static void Swap<T>(T a, T b)
        {
            Console.WriteLine("Before swapping the value of a={0} and b={1}.", a, b);

            T temp;
            temp = a;
            a = b;
            b = temp;

            Console.WriteLine("After swapping the value of a={0} and b={1}.", a, b);
        }

        static void Main(string[] args)
        {
            Swap(10, 20);
            Swap(23.5, 56.7);
        }
    }
}
