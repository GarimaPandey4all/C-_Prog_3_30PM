﻿using System;
using System.Collections;

namespace hashtableCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable hobj = new Hashtable();

            //Insert in a Hashtable
            hobj.Add("100", "Rishi");
            hobj.Add("101", "Brain");
            hobj.Add("102", "Dilip");
            hobj.Add("103", "Mohit");
            hobj.Add("104", "Amit");

            if(hobj.ContainsValue("Dilip"))
                Console.WriteLine("He is already in a list.");
            else
            hobj.Add("105", "Dilip");
            
            //Get a Collection of the keys
            ICollection key = hobj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + "  : " + hobj[str]);
        }
    }
}
