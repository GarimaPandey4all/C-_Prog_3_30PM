﻿using System;
using System.Collections;

namespace queueCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            Queue qobj = new Queue();

            //Insert in a Queue
            qobj.Enqueue('R');
            qobj.Enqueue('i');
            qobj.Enqueue('s');
            qobj.Enqueue('h');
            qobj.Enqueue('i');

            Console.WriteLine("Queue is:");
            foreach(char ch in qobj)
            Console.Write(ch + "  ");
            Console.WriteLine();

            //Remove/Delete value from the queue
            Console.WriteLine("Remove values from the Queue:");
            char character = (char)qobj.Dequeue();
            Console.WriteLine("Removed value is:{0}", character);

            character = (char)qobj.Dequeue();
            Console.WriteLine("Removed value is:{0}", character);

            Console.WriteLine("Queue is:");
            foreach(char ch in qobj)
            Console.Write(ch + "  ");
            Console.WriteLine();
        }
    }
}
