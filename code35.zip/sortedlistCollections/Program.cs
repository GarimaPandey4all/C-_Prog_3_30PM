﻿using System;
using System.Collections;

namespace sortedlistCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            //Sorted List: It is a combination of ArrayList(Access by Index value) and Hashtable(Access Key-value pair). 
            //It is always access the values in an ascending order.
            SortedList sobj = new SortedList();

            sobj.Add("100", "Rishi");
            sobj.Add("101", "Brain");
            sobj.Add("104", "Amit");
            sobj.Add("102", "Dilip");
            sobj.Add("103", "Mohit");

            if(sobj.ContainsValue("Dilip"))
                Console.WriteLine("He is already in a list.");
            else
            sobj.Add("105", "Dilip");
            
            //Get a Collection of the keys
            ICollection key = sobj.Keys;

            foreach(string str in key)
            Console.WriteLine(str + "  : " + sobj[str]);
        }
    }
}
