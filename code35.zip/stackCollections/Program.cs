﻿using System;
using System.Collections;

namespace stackCollections
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack sobj = new Stack();

            //Insert into a stack
            sobj.Push('R');
            sobj.Push('i');
            sobj.Push('s');
            sobj.Push('h');
            sobj.Push('i');

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            {
                Console.Write(ch + "  ");
            }
            Console.WriteLine();

            Console.WriteLine("Top value of stack is:{0}", sobj.Peek());

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            {
                Console.Write(ch + "  ");
            }
            Console.WriteLine();

            //Remove values from the stack
            sobj.Pop();
            sobj.Pop();

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            {
                Console.Write(ch + "  ");
            }
            Console.WriteLine();

            sobj.Push('C');
            sobj.Push('#');

            Console.WriteLine("Stack is:");
            foreach(char ch in sobj)
            {
                Console.Write(ch + "  ");
            }
            Console.WriteLine();
        }
    }
}
