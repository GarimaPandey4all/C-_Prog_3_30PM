﻿using System;

namespace adduserinput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter any value for a:");

            int a = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("Enter any value for b:");

            int b = Convert.ToInt32(Console.ReadLine());

            int c = a + b;

            Console.WriteLine("Addition of two numbers is:" + c);
        }
    }
}
