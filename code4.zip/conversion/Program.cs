﻿using System;

namespace conversion
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter your age:");

            int age = Convert.ToInt32(Console.ReadLine()); //Read User Input--> Convert String to Int

            Console.WriteLine("Age is:" + age);
        }
    }
}
