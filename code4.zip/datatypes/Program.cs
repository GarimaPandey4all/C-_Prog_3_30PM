﻿using System;

namespace datatypes
{
    class Program
    {
        static void Main(string[] args)
        {
            //Data Types:

            int num = 10; //Integer Number --> Size of int is: 4 bytes; 1 byte = 8 bits; 4 bytes = 32 bits
            long num2 = 2300000000000L; // 8 bytes = 64 bits

            float floatnum = 23.56F; // 4 bytes = 32 bits // six or seven decimal digits
            double doublenum = 34.67; //Floating Point Number --> 8 bytes; 8 bytes = 64 bits // 15 decimal digits

            char ch = 'E'; // Character/Symbol --> 2 bytes; 2 bytes = 16 bits

            bool state = true; //Boolean --> 1 bit

            string name = "Brain"; //String --> 2 bytes per character

            Console.WriteLine(num);
            Console.WriteLine(num2);

            Console.WriteLine(floatnum);
            Console.WriteLine(doublenum);

            Console.WriteLine(ch);

            Console.WriteLine(state);

            Console.WriteLine(name);
        }
    }
}
