﻿using System;

namespace userinput
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter Username:");

            string userName = Console.ReadLine(); //Read user input

            Console.WriteLine("Username is:" + userName);

        }
    }
}
