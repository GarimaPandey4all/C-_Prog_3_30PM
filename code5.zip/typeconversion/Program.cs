﻿using System;

namespace typeconversion
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 10;

            double doublenum = num; //Implicit Casting/Conversion: int to double

            Console.WriteLine(num);

            Console.WriteLine(doublenum);
        }
    }
}
