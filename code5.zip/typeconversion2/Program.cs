﻿using System;

namespace typeconversion2
{
    class Program
    {
        static void Main(string[] args)
        {
            double doublenum = 34.5;

            int num = (int) doublenum; //Explicitly/manually casting/conversion: double to int

            Console.WriteLine(doublenum);

            Console.WriteLine(num);
        }
    }
}
