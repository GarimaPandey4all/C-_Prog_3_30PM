﻿using System;

namespace typeconversionmethods
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 20;

            double doublenum = 34.2;

            bool state = true;

            Console.WriteLine(Convert.ToString(num)); // int to string
            Console.WriteLine(Convert.ToDouble(num)); // int to double
            Console.WriteLine(Convert.ToInt32(doublenum)); // double to int
            Console.WriteLine(Convert.ToString(state)); // bool to string
        }
    }
}
