﻿using System;

namespace arithmeticOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a, b;

            Console.WriteLine("Enter any value for a:");
            a = Convert.ToInt32(Console.ReadLine());

             Console.WriteLine("Enter any value for b:");
            b = Convert.ToInt32(Console.ReadLine());

            //Addition

            Console.WriteLine("Addition of two numbers is:" + (a+b));

            //Subtraction

            Console.WriteLine("Subtraction of two numbers is:" + (a-b));

            //Multiplication

            Console.WriteLine("Multiplication of two numbers is:" + (a*b));

            //Division

            Console.WriteLine("Division of two numbers is:" + (a/b));

            //Modulus

            Console.WriteLine("Modulus of two numbers is:" + (a%b)); // a= 10, b = 9

            //Increment , Pre and Post

            Console.WriteLine("Pre-Increment of a is:" + (++a));

            Console.WriteLine("Post-Increment of a is:" + (a++));

            Console.WriteLine("a is:" + a);

            //Decrement , Pre and Post

            Console.WriteLine("Pre-Decrement of b is:" + (--b));

            Console.WriteLine("Post-Decrement of b is:" + (b--));

            Console.WriteLine("b is:" + b);
        }
    }
}
