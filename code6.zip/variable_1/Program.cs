﻿using System;

namespace variable_1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10;
            int b = 30;

            int c = a+b; //+ operator: Addition perform 

            Console.WriteLine(c);
        }
    }
}
