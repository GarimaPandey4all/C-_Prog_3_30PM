﻿using System;

namespace variable_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int add = 20 + 40;
            int add2 = add + 50;
            int add3 = add2 + add2;

            Console.WriteLine(add);
            Console.WriteLine(add2);
            Console.WriteLine(add3);

        }
    }
}
