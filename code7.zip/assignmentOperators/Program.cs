﻿using System;

namespace assignmentOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10; // = --> assignment operator, it is used to assign values to variables.
           Console.WriteLine(a);

           // +=, -= , *=, /=, %=

           a += 5; //a = a + 5;

           Console.WriteLine(a);

           a -= 5; //a = a - 5;

           Console.WriteLine(a);

           a *= 10; //a = a * 10;

           Console.WriteLine(a);

           a /= 15; //a = a / 15;

           Console.WriteLine(a);

           a %= 5; //a = a % 5;

           Console.WriteLine(a);

           // &=, |=, ^=, >>=, <<=: Binary Operators

           int b = 3; //

           b &= 2; // b = b & 2; // Output: 2

           Console.WriteLine(b);

           int c = 3;
           c |= 2; //c = c | 2; // Output: 3

           Console.WriteLine(c);

            //^ --> Binary X-Or Operator
           int d = 5;

           d ^= 3;

           Console.WriteLine(d);

           //>>-Right shift Operator, <<-Left Shift Operator

           int x = 3;

           x >>= 1;

           Console.WriteLine(x);

            int y = 15;

            y >>= 3;

            Console.WriteLine(y);

            //Left Shift
            int z = 5;

            z <<= 3;

            Console.WriteLine(z);

        }
    }
}
