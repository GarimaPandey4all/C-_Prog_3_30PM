﻿using System;

namespace comparisonRelationalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            //Comparison = compare between two values

            int a=10, b=10;

            //==
            Console.WriteLine(a == b); // ==: Equal to operator // 10 == 5--> False // 10 == 10 -->True

            // != , Not equal to operator

            b = 5;

            Console.WriteLine(a != b); 

            // >, Greather than  operator

            Console.WriteLine(a > b);  // 10 > 5

            // <, Less than  operator

            Console.WriteLine(b < a);  // 5 < 10

             // >=, Greather than equal to  operator

            Console.WriteLine(a >= b);  // 10 >= 5

            // <=, Less than  equal to operator

            Console.WriteLine(b <= a);  // 5 <= 10 
            Console.WriteLine(b <= 4);        
        }
    }
}
