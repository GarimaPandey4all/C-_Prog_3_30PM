﻿using System;

namespace logicalOperators
{
    class Program
    {
        static void Main(string[] args)
        {
            int y = 6;

            // && --> Logical And Operator
            Console.WriteLine(y > 4 && y < 9 && y == 6); // True && True && True = True 

            Console.WriteLine(y > 7 && y < 9 && y == 6); // False && True && True = False

            // || --> Logical OR Operator
            Console.WriteLine(y > 4 || y < 9 || y == 6); // True || True || True = True 

            Console.WriteLine(y > 7 || y < 5 || y == 6); // False || False || True = True

            // ! --> Logical Not Operator
            Console.WriteLine(!(y > 4 || y < 9 || y == 6)); // True || True || True = !(True) = False
        }
    }
}
