﻿using System;

namespace mathmethods
{
    class Program
    {
        static void Main(string[] args)
        {
            //Math.Max(x, y): find highest value

            Console.WriteLine(Math.Max(3, 7));  

            //Math.Min(x, y): find smallest value

            Console.WriteLine(Math.Min(3, 7));

            //Math.Sqrt(): find square root 

            Console.WriteLine(Math.Sqrt(9));

            Console.WriteLine(Math.Sqrt(16));

            //Math.Round(): find round number to the nearest whole number

            Console.WriteLine(Math.Round(10.89));

            //Math.Abs(): returns the absolute positive value 

            Console.WriteLine(Math.Abs(-5.9));

        }
    }
}
